<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data Penjualan Tiket</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard">
                    <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data Penjualan Tiket</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data Penjualan Tiket</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Pembeli</th>
                                        <th>Match</th>
                                        <th>Kategory</th>
                                        <th>Jumlah</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $getAllTiket = mysqli_query($koneksi, "SELECT * FROM `view_detail_penjualan_tiket`");
                                        foreach ($getAllTiket as $key => $t) {
                                    ?>
                                        <tr>
                                            <td><?= $key+1; ?></td>
                                            <td><?= $t['order_date']; ?></td>
                                            <td><?= $t['nama_pembeli']; ?></td>
                                            <td>PSS Sleman vs <?= $t['lawan']; ?></td>
                                            <td><?= $t['category']; ?></td>
                                            <td><?= $t['quantity']; ?></td>
                                            <td><?= $t['total']; ?></td>
                                        </tr>
                                        <!-- Modal Detail -->
                                        <div class="modal fade" id="modalDetail<?= $t['ticket_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="fw-bold">PSS Sleman vs <?= $t['opponent']; ?> : <?= $t['status']; ?></p>
                                                        <p>Tanggal : <?= $t['match_date']; ?></p>
                                                        <p>Lokasi : <?= $t['location']; ?></p>
                                                        <p class="fw-bold">Tiket</p>
                                                        <p>Kategori : <?= $t['category']; ?></p>
                                                        <p>Harga : <?= $t['price']; ?></p>
                                                        <p>Stok : <?= $t['stock']; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="modalEdit<?= $t['ticket_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="category" class="form-label">Kategori</label>
                                                                <select name="category" id="category" class="form-control">
                                                                    <option value="<?= $t['category']; ?>"><?= $t['category']; ?></option>
                                                                    <option value="VIP">VIP</option>
                                                                    <option value="Ekonomi">Ekonomi</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="price" class="form-label">Harga</label>
                                                                <input value="<?= $t['price']; ?>" type="text" class="form-control" name="price" id="price" placeholder="Kategori" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="stock" class="form-label">Stok</label>
                                                                <input value="<?= $t['stock']; ?>" type="text" class="form-control" name="stock" id="stock" placeholder="Kategori" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" type="submit" name="update" value="<?= $t['ticket_id']; ?>">Edit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="modalHapus<?= $t['ticket_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <p>Yakin ingin hapus?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" value="<?= $t['ticket_id']; ?>" type="submit" name="delete">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="opponent" class="form-label">Lawan</label>
                        <select name="opponent" id="opponent" class="form-control">
                            <?php 
                                $getAllMatch = mysqli_query($koneksi, "SELECT * FROM matches");
                                foreach ($getAllMatch as $key => $m) {
                            ?>
                                <option value="<?= $m['match_id']?>">PSS Sleman vs <?= $m['opponent']?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">Kategori</label>
                        <select name="category" id="category" class="form-control">
                            <option value="VIP">VIP</option>
                            <option value="Ekonomi">Ekonomi</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Harga</label>
                        <input type="text" class="form-control" name="price" id="price" placeholder="Kategori" required>
                    </div>
                    <div class="mb-3">
                        <label for="stock" class="form-label">Stok</label>
                        <input type="text" class="form-control" name="stock" id="stock" placeholder="Kategori" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="add">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>