<?php 
    if (isset($_POST['add'])) {
        $name = $_POST['name'];
        $kta_number = $_POST['kta_number'];
        $created_at = date('Y-m-d');

        $query = mysqli_query($koneksi, "INSERT INTO users VALUES ('','$name','123','','$kta_number','$created_at')");
    }
    if (isset($_POST['update'])) {
        $id = $_POST['update'];
        $name = $_POST['name'];
        $kta_number = $_POST['kta_number'];

        $query = mysqli_query($koneksi, "UPDATE users SET name = '$name', kta_number = '$kta_number' WHERE user_id = '$id'");
    }
    if (isset($_POST['delete'])) {
        $id = $_POST['delete'];

        $query = mysqli_query($koneksi, "DELETE FROM users WHERE user_id = '$id'");
    }
?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data User</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard">
                    <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data User</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data User</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>No. KTA</th>
                                        <th>Total Transaksi</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $getAllUser = mysqli_query($koneksi, "SELECT * FROM users WHERE role != 'admin'");
                                        $getAllUserTransaksi = mysqli_query($koneksi, "CALL `sp_hitung_total_pendapatan_per_user`();");
                                        while ($row = mysqli_fetch_assoc($getAllUserTransaksi)) {
                                            $data[$row['user_id']] = $row;
                                        }
                                        foreach ($getAllUser as $key => $u) {
                                    ?>
                                        <tr>
                                            <td><?= $key+1; ?></td>
                                            <td><?= $u['name']; ?></td>
                                            <td><?= $u['kta_number']; ?></td>
                                            <td><?= isset($data[$u['user_id']])?$data[$u['user_id']]['total_pendapatan']:'0'; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-icon btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $u['user_id']; ?>"><i class="fas fa-pen"></i></button>
                                                <button type="button" class="btn btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $u['user_id']; ?>"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="modalEdit<?= $u['user_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="name" class="form-label">Nama</label>
                                                                <input value="<?= $u['name']; ?>" type="text" class="form-control" name="name" id="name" placeholder="Nama" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="kta_number" class="form-label">No. KTA</label>
                                                                <input value="<?= $u['kta_number']; ?>" type="text" class="form-control" name="kta_number" id="kta_number" placeholder="No. KTA" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" type="submit" name="update" value="<?= $u['user_id']; ?>">Edit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="modalHapus<?= $u['user_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <p>Yakin ingin hapus?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" value="<?= $u['user_id']; ?>" type="submit" name="delete">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="kta_number" class="form-label">No. KTA</label>
                        <input type="text" class="form-control" name="kta_number" id="kta_number" placeholder="No. KTA" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="add">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>