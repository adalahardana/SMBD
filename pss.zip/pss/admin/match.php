<?php 
    if (isset($_POST['add'])) {
        $liga = $_POST['liga'];
        $opponent = $_POST['opponent'];
        $match_date = $_POST['match_date'];
        $location = $_POST['location'];
        $status = $_POST['status'];

        $query = mysqli_query($koneksi, "INSERT INTO matches VALUES ('', '$liga', '$opponent', '$match_date', '$location', '$status')");
    }
    if (isset($_POST['update'])) {
        $id = $_POST['update'];
        $liga = $_POST['liga'];
        $opponent = $_POST['opponent'];
        $match_date = $_POST['match_date'];
        $location = $_POST['location'];
        $status = $_POST['status'];

        $query = mysqli_query($koneksi, "UPDATE matches SET competition_id = '$liga', opponent = '$opponent', match_date = '$match_date', location = '$location', status = '$status' WHERE match_id = '$id'");
    }
    if (isset($_POST['delete'])) {
        $id = $_POST['delete'];

        $query = mysqli_query($koneksi, "DELETE FROM matches WHERE match_id = '$id'");
    }
?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data Pertandingan</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="dashboard">
                    <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Data Pertandingan</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data Pertandingan</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Liga</th>
                                        <th>Lawan</th>
                                        <th>Tanggal</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $getAllMatch = mysqli_query($koneksi, "SELECT * FROM matches JOIN competitions ON matches.competition_id = competitions.competition_id");
                                        foreach ($getAllMatch as $key => $m) {
                                    ?>
                                        <tr>
                                            <td><?= $key+1; ?></td>
                                            <td><?= $m['name']; ?></td>
                                            <td>PSS Sleman vs <?= $m['opponent']; ?></td>
                                            <td><?= $m['match_date']; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-icon btn-info" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $m['match_id']; ?>"><i class="fas fa-info"></i></button>
                                                <button type="button" class="btn btn-icon btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $m['match_id']; ?>"><i class="fas fa-pen"></i></button>
                                                <button type="button" class="btn btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $m['match_id']; ?>"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                        <!-- Modal Detail -->
                                        <div class="modal fade" id="modalDetail<?= $m['match_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="fw-bold">PSS SLEMAN vs <?= $m['opponent']; ?> : <?= $m['status']; ?></p>
                                                        <p>Liga : <?= $m['name']; ?> Season <?= $m['season']; ?></p>
                                                        <p>Tanggal : <?= $m['match_id']; ?></p>
                                                        <p>Lokasi : <?= $m['location']; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="modalEdit<?= $m['match_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <div class="modal-body">
                                                                <div class="mb-3">
                                                                    <label for="liga" class="form-label">Lawan</label>
                                                                    <select name="liga" id="liga" class="form-control">
                                                                        <option value="<?= $m['competition_id']?>"><?= $m['name']?> Season <?= $m['season']?></option>
                                                                        <?php 
                                                                            $getAllComp = mysqli_query($koneksi, "SELECT * FROM competitions");
                                                                            foreach ($getAllComp as $key => $c) {
                                                                        ?>
                                                                            <option value="<?= $c['competition_id']?>"><?= $c['name']?> Season <?= $c['season']?></option>
                                                                        <?php } ?>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="opponent" class="form-label">Lawan</label>
                                                                    <input value="<?= $m['opponent']; ?>" type="text" class="form-control" name="opponent" id="opponent" placeholder="Lawan" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="match_date" class="form-label">Tanggal</label>
                                                                    <input value="<?= $m['match_date']; ?>" type="date" class="form-control" name="match_date" id="match_date" placeholder="Tanggal" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="location" class="form-label">Lokasi</label>
                                                                    <input value="<?= $m['location']; ?>" type="text" class="form-control" name="location" id="location" placeholder="Lokasi" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="status" class="form-label">Status</label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="<?= $m['status']; ?>"><?= $m['status']; ?></option>
                                                                        <option value="selesai">Selesai</option>
                                                                        <option value="akan datang">Akan Datang</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" type="submit" value="<?= $m['match_id']; ?>" name="update">Edit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal Hapus -->
                                        <div class="modal fade" id="modalHapus<?= $m['match_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                                    </div>
                                                    <form action="" method="post">
                                                        <div class="modal-body">
                                                            <p>Yakin ingin hapus?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-primary" value="<?= $m['match_id']; ?>" type="submit" name="delete">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="liga" class="form-label">Lawan</label>
                        <select name="liga" id="liga" class="form-control">
                            <?php 
                                $getAllComp = mysqli_query($koneksi, "SELECT * FROM competitions");
                                foreach ($getAllComp as $key => $c) {
                            ?>
                                <option value="<?= $c['competition_id']?>"><?= $c['name']?> Season <?= $c['season']?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="opponent" class="form-label">Lawan</label>
                        <input type="text" class="form-control" name="opponent" id="opponent" placeholder="Lawan" required>
                    </div>
                    <div class="mb-3">
                        <label for="match_date" class="form-label">Tanggal</label>
                        <input type="date" class="form-control" name="match_date" id="match_date" placeholder="Tanggal" required>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Lokasi</label>
                        <input type="text" class="form-control" name="location" id="location" placeholder="Lokasi" required>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="selesai">Selesai</option>
                            <option value="akan datang">Akan Datang</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="add">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>