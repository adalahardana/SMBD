<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-hijau px-3"></h6>
            <h1 class="mb-5">Pertandingan Mendatang</h1>
        </div>
        <div class="row g-4 justify-content-center">
            <?php 
                include 'koneksi.php';
                $getMatchMendatang = mysqli_query($koneksi, "SELECT * FROM matches ORDER BY match_id DESC");
                foreach ($getMatchMendatang as $key => $mm) {
            ?>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="course-item bg-light">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/hero.jpg" alt="">
                        <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                            <?php if ($mm['status'] == 'akan datang') { ?>
                                <span class="btn-no-hover flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0px 0px 30px;">Akan Datang</span>
                                <a href="beli?order=tiket&ticket=<?= $mm['match_id']; ?>" class="flex-shrink-0 btn btn-sm btn-primary px-3" style="border-radius: 0px 30px 30px 0px;">Tiket</a>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="text-center p-4 pb-0">
                        <h5 class="mb-4">PSS Sleman vs <?= $mm['opponent']; ?></h5>
                    </div>
                    <div class="d-flex border-top">
                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-light me-2"></i><?= $mm['match_date']; ?></small>
                        <small class="flex-fill text-center py-2"><i class="fa fa-user text-light me-2"></i><?= $mm['location']; ?></small>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>