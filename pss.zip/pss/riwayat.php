<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-hijau px-3"></h6>
            <h3 class="mb-5">Riwayat Transaksi</h3>
        </div>
        <table class="table table-bordered table-secondary border-dark">
            <tr>
                <th class="text-center">No</th>
                <th class="text-center">Tanggal</th>
                <th class="text-center" colspan="2">Item</th>
                <th class="text-center">Tipe</th>
                <th class="text-center">Jumlah</th>
                <th class="text-center">Total</th>
            </tr>
            <?php 
                $id = $_SESSION['userLogin']['user_id'];
                $query = mysqli_query($koneksi, "CALL sp_get_orders_by_user('$id')");
                if (mysqli_num_rows($query)) {
                foreach ($query as $key => $d) {
            ?>
            <tr>
                <th scope="row"><?= $key+1; ?></th>
                <td><?= $d['order_date']; ?></td>
                <td><?= $d['lawan'] == null ? 'Merchandise' : 'Ticket'; ?></td>
                <td><?= $d['lawan'] == null ? $d['nama_merchandise'] : 'PSS Sleman vs '.$d['lawan']; ?></td>
                <td><?= $d['lawan'] == null ? $d['category_merch'] : $d['category_tiket']; ?></td>
                <td><?= $d['quantity']; ?></td>
                <td><?= $d['total']; ?></td>
            </tr>
            <?php }} else { ?>
            <tr>
                <th scope="row" colspan="7">Data Kosong</th>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>


