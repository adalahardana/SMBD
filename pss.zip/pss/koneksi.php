<?php 
// Mulai session jika belum
if (!isset($_SESSION)) { 
    session_start(); 
}

// Buat koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "pss");

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Atur charset dan collation agar cocok dengan kolom di database
mysqli_set_charset($koneksi, 'utf8mb4');
mysqli_query($koneksi, "SET collation_connection = 'utf8mb4_0900_ai_ci'");
?>
